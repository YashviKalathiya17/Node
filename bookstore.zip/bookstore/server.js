const express = require("express");
const mongoose = require("mongoose");
require("dotenv").config();

const bookRoutes = require("./routes/bookRoutes");

const app = express();
app.use(express.json());

// API routes
app.use("/api/books", bookRoutes);

// 👇 Root route
app.get("/", (req, res) => {
  res.send("📚 Welcome to the Bookstore API. Use /api/books");
});

const PORT = process.env.PORT || 3000;

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✅ MongoDB connected...");
    app.listen(PORT, () => 
      console.log(`🚀 Server running on http://localhost:${PORT}`)
    );
  })
  .catch(err => console.error(err));
